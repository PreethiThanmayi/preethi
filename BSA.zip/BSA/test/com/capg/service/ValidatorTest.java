package com.capg.service;

import static org.junit.Assert.*;

import org.junit.Test;

public class ValidatorTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
